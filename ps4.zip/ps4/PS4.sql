﻿CREATE DATABASE PS4_Gold;
GO
USE PS4_Gold;
GO

-- =====================================================================
-- PS4 – Gold layer (star schema) – MS SQL Server

-- =====================================================================


IF OBJECT_ID('dbo.fact_shipment','U') IS NOT NULL DROP TABLE dbo.fact_shipment;
IF OBJECT_ID('dbo.dim_shipper','U')   IS NOT NULL DROP TABLE dbo.dim_shipper;
IF OBJECT_ID('dbo.dim_date','U')      IS NOT NULL DROP TABLE dbo.dim_date;

CREATE TABLE dbo.dim_shipper (
    shipper_key      INT           NOT NULL PRIMARY KEY,   -- khoá đại diện (tự sinh)
    shipper_id       VARCHAR(20)   NOT NULL UNIQUE,        -- khoá nghiệp vụ (SHPxxxxx)
    shipper_name     NVARCHAR(100) NULL,
    shipper_company  NVARCHAR(100) NULL,
    city             NVARCHAR(100) NULL,
    region           NVARCHAR(50)  NULL,
    district         NVARCHAR(100) NULL,
    shipper_vehicle  NVARCHAR(50)  NULL,
    working_shift    NVARCHAR(50)  NULL
);

CREATE TABLE dbo.dim_date (
    date_key   INT  NOT NULL PRIMARY KEY,   -- yyyymmdd
    full_date  DATE NOT NULL,
    [month]    TINYINT NOT NULL,
    [quarter]  TINYINT NOT NULL,
    [year]     SMALLINT NOT NULL
);

CREATE TABLE dbo.fact_shipment (
    order_id               INT           NOT NULL PRIMARY KEY,   -- 1 dòng = 1 đơn có vận đơn
    shipper_key            INT           NOT NULL,
    date_key               INT           NOT NULL,               -- lấy từ ship_date
    order_status           NVARCHAR(20)  NOT NULL,
    return_reason          NVARCHAR(30)  NULL,
    comment                NVARCHAR(500) NULL,
    sentiment              NVARCHAR(10)  NULL,                   -- Positive / Neutral / Negative
    delivery_duration_days TINYINT       NOT NULL,
    avg_rating             DECIMAL(4,2)  NULL,                   -- TB rating các review của đơn (NULL nếu chưa có review)
    is_failed              BIT           NOT NULL,               -- order_status = 'returned'
    is_late_return         BIT           NOT NULL,               -- có return_reason = 'late_delivery'
    CONSTRAINT FK_fact_shipper FOREIGN KEY (shipper_key) REFERENCES dbo.dim_shipper(shipper_key),
    CONSTRAINT FK_fact_date    FOREIGN KEY (date_key)    REFERENCES dbo.dim_date(date_key)
);

CREATE INDEX IX_fact_shipper ON dbo.fact_shipment(shipper_key);
CREATE INDEX IX_fact_date    ON dbo.fact_shipment(date_key);
