USE PS4_Gold;
GO
-- =====================================================================
-- PS4 – Metric & KPI trên Gold. Chạy sau khi nạp dữ liệu xong.
-- KPI1 = AVG(rating)/5*100 ; KPI2 = 100 - complaint_rate(%) ;
-- KPI3 = 100 - returned_rate(%) ; KPI tổng hợp = 0.4*KPI1 + 0.3*KPI2 + 0.3*KPI3
-- Thang Likert 4 mức: chia khoảng đều giữa KPI nhỏ nhất và lớn nhất
-- =====================================================================
IF OBJECT_ID('dbo.vw_shipper_metric','V') IS NOT NULL DROP VIEW dbo.vw_shipper_metric;
GO
CREATE VIEW dbo.vw_shipper_metric AS
SELECT  s.shipper_id, s.shipper_name, s.shipper_company, s.region,
        COUNT(f.order_id)                               AS m1_total_orders,
        AVG(CAST(f.avg_rating AS FLOAT))                AS m2_avg_rating,
        SUM(CAST(f.is_failed AS INT))                   AS m3_failed_orders,
        SUM(CAST(f.is_late_return AS INT))              AS m4_late_delivery_complaints,
        100.0 * SUM(CAST(f.is_failed AS INT))      / COUNT(f.order_id) AS returned_rate_pct,
        100.0 * SUM(CAST(f.is_late_return AS INT)) / COUNT(f.order_id) AS complaint_rate_pct
FROM dbo.fact_shipment f
JOIN dbo.dim_shipper s ON s.shipper_key = f.shipper_key
GROUP BY s.shipper_id, s.shipper_name, s.shipper_company, s.region;
GO
IF OBJECT_ID('dbo.vw_shipper_kpi','V') IS NOT NULL DROP VIEW dbo.vw_shipper_kpi;
GO
CREATE VIEW dbo.vw_shipper_kpi AS
WITH k AS (
    SELECT  *,
            m2_avg_rating / 5.0 * 100        AS kpi1_customer_satisfaction,
            100.0 - complaint_rate_pct       AS kpi2_complaint_performance,
            100.0 - returned_rate_pct        AS kpi3_delivery_reliability
    FROM dbo.vw_shipper_metric
), t AS (
    SELECT  *,
            0.4*kpi1_customer_satisfaction + 0.3*kpi2_complaint_performance
          + 0.3*kpi3_delivery_reliability AS kpi_total
    FROM k
), q AS (
    SELECT  *,
            MIN(kpi_total) OVER () AS kmin,
            MAX(kpi_total) OVER () AS kmax
    FROM t
)
SELECT  *,
        RANK() OVER (ORDER BY kpi_total DESC) AS kpi_rank,
        CASE WHEN kpi_total < kmin + (kmax-kmin)*0.25 THEN 1
             WHEN kpi_total < kmin + (kmax-kmin)*0.50 THEN 2
             WHEN kpi_total < kmin + (kmax-kmin)*0.75 THEN 3
             ELSE 4 END AS likert_score,
        CASE WHEN kpi_total < kmin + (kmax-kmin)*0.25 THEN N'Thấp'
             WHEN kpi_total < kmin + (kmax-kmin)*0.50 THEN N'Trung bình'
             WHEN kpi_total < kmin + (kmax-kmin)*0.75 THEN N'Tốt'
             ELSE N'Xuất sắc' END AS grade
FROM q;
GO
-- Xem kết quả:
-- SELECT * FROM dbo.vw_shipper_kpi ORDER BY kpi_rank;

