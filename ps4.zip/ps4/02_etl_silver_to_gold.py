"""
PS4 – ETL: Silver (CSV) -> Gold (star schema) trong MS SQL Server.

Cách dùng
---------
1) Chạy 01_create_tables.sql trong SSMS (tạo bảng rỗng).
2) pip install pandas sqlalchemy pyodbc
3) Chạy thử KHÔNG cần SQL Server (chỉ xuất CSV + kiểm tra):
       python 02_etl_silver_to_gold.py --silver-dir "D:/.../file_cat_du_lieu" --dry-run
4) Nạp vào SQL Server:
       python 02_etl_silver_to_gold.py --silver-dir "D:/.../file_cat_du_lieu" \
              --server "localhost\\SQLEXPRESS" --database PS4_Gold
   (mặc định dùng Windows Authentication; nếu dùng SQL login thêm --user sa --password ***)
"""
import argparse, os, sys
import pandas as pd

# ---- 18 mẫu comment -> sentiment (do nhóm tự phân loại) ----
NEG = {
 'Cần cải thiện tốc độ hỗ trợ vào giờ cao điểm.',
 'Khách hàng mong muốn nhân viên tư vấn chi tiết hơn.',
 'Một số thắc mắc phải liên hệ nhiều lần mới được giải quyết.',
 'Khách hàng phản ánh thời gian phản hồi còn chậm nhưng vấn đề đã được xử lý.'}
NEU = {
 'Khách hàng không có thêm phản hồi về chất lượng hỗ trợ.',
 'Quá trình hỗ trợ diễn ra bình thường, đúng quy trình.',
 'Dịch vụ đáp ứng yêu cầu cơ bản, chưa phát sinh vấn đề đáng kể.',
 'Khách hàng đánh giá mức độ hài lòng ở mức khá.'}

def sentiment(c):
    if pd.isna(c): return None
    return 'Negative' if c in NEG else ('Neutral' if c in NEU else 'Positive')

def build(silver):
    rd = lambda n, **kw: pd.read_csv(os.path.join(silver, n), **kw)
    shp = rd('shipments_realistic_3nf.csv', parse_dates=['ship_date', 'delivery_date'])
    odr = rd('orders_enriched_3nf.csv', usecols=['order_id', 'order_status', 'comment'])
    rev = rd('reviews_3nf.csv', usecols=['order_id', 'rating'])
    ret = rd('returns_3nf.csv', usecols=['order_id', 'return_reason'])
    sph = rd('shippers_3nf.csv')

    # ---- dim_shipper ----
    cols = ['shipper_id', 'shipper_name', 'shipper_company', 'city', 'region',
            'district', 'shipper_vehicle', 'working_shift']
    dim_shipper = sph[cols].drop_duplicates('shipper_id').sort_values('shipper_id').reset_index(drop=True)
    dim_shipper.insert(0, 'shipper_key', range(1, len(dim_shipper) + 1))

    # ---- dim_date (theo ship_date) ----
    days = pd.date_range(shp.ship_date.min(), shp.ship_date.max(), freq='D')
    dim_date = pd.DataFrame({'full_date': days})
    dim_date['date_key'] = dim_date.full_date.dt.strftime('%Y%m%d').astype(int)
    dim_date['month'] = dim_date.full_date.dt.month
    dim_date['quarter'] = dim_date.full_date.dt.quarter
    dim_date['year'] = dim_date.full_date.dt.year
    dim_date = dim_date[['date_key', 'full_date', 'month', 'quarter', 'year']]
    dim_date['full_date'] = dim_date.full_date.dt.date

    # ---- gộp review / return về mức đơn hàng (tránh nhân đôi dòng) ----
    rating = rev.groupby('order_id').rating.mean().round(2).rename('avg_rating').reset_index()
    ret['is_late'] = (ret.return_reason == 'late_delivery')
    ret_o = (ret.sort_values('is_late', ascending=False)        # ưu tiên lý do late_delivery
                .groupby('order_id')
                .agg(return_reason=('return_reason', 'first'), is_late_return=('is_late', 'max'))
                .reset_index())

    f = (shp.merge(odr, on='order_id', how='left')
            .merge(rating, on='order_id', how='left')
            .merge(ret_o, on='order_id', how='left')
            .merge(dim_shipper[['shipper_key', 'shipper_id']], on='shipper_id', how='left'))
    f['date_key'] = f.ship_date.dt.strftime('%Y%m%d').astype(int)
    f['sentiment'] = f.comment.map(sentiment)
    f['is_failed'] = (f.order_status == 'returned').astype(int)
    f['is_late_return'] = f.is_late_return.astype('boolean').fillna(False).astype(int)
    fact = f[['order_id', 'shipper_key', 'date_key', 'order_status', 'return_reason', 'comment',
              'sentiment', 'delivery_duration_days', 'avg_rating', 'is_failed', 'is_late_return']]
    return dim_shipper, dim_date, fact, shp

def validate(dim_shipper, dim_date, fact, shp):
    ok = True
    def chk(name, cond, extra=''):
        nonlocal ok
        print(('[OK]   ' if cond else '[LỖI] ') + name, extra); ok &= bool(cond)
    chk('Số dòng fact = số dòng shipments', len(fact) == len(shp), f'({len(fact):,})')
    chk('order_id không trùng', fact.order_id.is_unique)
    chk('shipper_key không rỗng', fact.shipper_key.notna().all())
    chk('date_key đều có trong dim_date', fact.date_key.isin(dim_date.date_key).all())
    chk('order_status không rỗng', fact.order_status.notna().all())
    chk('Có đúng 18 mẫu comment', fact.comment.nunique() == 18, f'({fact.comment.nunique()})')
    print(f'       Số shipper: {len(dim_shipper)}; đơn returned: {fact.is_failed.sum():,}; '
          f'đơn late_delivery: {fact.is_late_return.sum():,}; đơn có rating: {fact.avg_rating.notna().sum():,}')
    return ok

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--silver-dir', required=True)
    ap.add_argument('--dry-run', action='store_true', help='không kết nối SQL Server, chỉ xuất CSV vào ./gold_preview')
    ap.add_argument('--server'); ap.add_argument('--database', default='PS4_Gold')
    ap.add_argument('--user'); ap.add_argument('--password')
    ap.add_argument('--driver', default='ODBC Driver 17 for SQL Server')
    a = ap.parse_args()

    dim_shipper, dim_date, fact, shp = build(a.silver_dir)
    if not validate(dim_shipper, dim_date, fact, shp):
        sys.exit('Kiểm tra dữ liệu thất bại, dừng.')

    if a.dry_run:
        os.makedirs('gold_preview', exist_ok=True)
        for n, d in [('dim_shipper', dim_shipper), ('dim_date', dim_date), ('fact_shipment', fact)]:
            d.to_csv(f'gold_preview/{n}.csv', index=False, encoding='utf-8-sig')
        print('Đã xuất CSV vào ./gold_preview (dry-run).'); return

    from sqlalchemy import create_engine, text
    from urllib.parse import quote_plus
    auth = f'UID={a.user};PWD={a.password}' if a.user else 'Trusted_Connection=yes'
    cs = quote_plus(f'DRIVER={{{a.driver}}};SERVER={a.server};DATABASE={a.database};{auth};TrustServerCertificate=yes')
    eng = create_engine(f'mssql+pyodbc:///?odbc_connect={cs}', fast_executemany=True)
    with eng.begin() as con:                       # nạp theo thứ tự: chiều trước, fact sau
        con.execute(text('DELETE FROM dbo.fact_shipment'))
        con.execute(text('DELETE FROM dbo.dim_shipper'))
        con.execute(text('DELETE FROM dbo.dim_date'))
        dim_shipper.to_sql('dim_shipper', con, schema='dbo', if_exists='append', index=False)
        dim_date.to_sql('dim_date', con, schema='dbo', if_exists='append', index=False)
        fact.to_sql('fact_shipment', con, schema='dbo', if_exists='append', index=False, chunksize=20000)
    # Kiểm tra lại bằng một KẾT NỐI MỚI (sau khi giao dịch đã commit)
    with eng.connect() as chk:
        srv, db = chk.execute(text('SELECT @@SERVERNAME, DB_NAME()')).one()
        print(f'Kết nối kiểm tra: server = {srv} | database = {db}')
        for t, exp in [('dim_shipper', len(dim_shipper)), ('dim_date', len(dim_date)), ('fact_shipment', len(fact))]:
            n = chk.execute(text(f'SELECT COUNT(*) FROM dbo.{t}')).scalar()
            print(f'  dbo.{t}: {n:,} dòng (kỳ vọng {exp:,}) ' + ('OK' if n == exp else '<<< KHÔNG KHỚP'))

if __name__ == '__main__':
    main()
